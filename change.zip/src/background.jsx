import React from "react";
import { useGLTF, OrbitControls } from "@react-three/drei";

function background(props) {
  const { scene } = useGLTF("/Terrain.glb");
  // console.log(bg)
  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1.5} />
      <primitive object={scene} scale={[8, 8, 8]} {...props} />;
    </>
  );
}

export default background;
