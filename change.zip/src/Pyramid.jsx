import { useRef, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, useGLTF } from '@react-three/drei';
import { useControls } from 'leva';
import gsap from 'gsap';

function Pyramid() {
  const { nodes } = useGLTF('/triangle.glb'); // Your GLB file
  const part1Ref = useRef();
  const part2Ref = useRef();
  const part3Ref = useRef();

  // Leva controls for position
  const part1Pos = useControls('Part 1 Position', {
    x: { value: 2, min: -10, max: 10, step: 0.1 },
    y: { value: 0, min: -10, max: 10, step: 0.1 },
    z: { value: 0, min: -10, max: 10, step: 0.1 },
  });

  const part2Pos = useControls('Part 2 Position', {
    x: { value: 0, min: -10, max: 10, step: 0.1 },
    y: { value: 2, min: -10, max: 10, step: 0.1 },
    z: { value: 0, min: -10, max: 10, step: 0.1 },
  });

  const part3Pos = useControls('Part 3 Position', {
    x: { value: 2, min: -10, max: 10, step: 0.1 },
    y: { value: 0, min: -10, max: 10, step: 0.1 },
    z: { value: 0, min: -10, max: 10, step: 0.1 },
  });

  useEffect(() => {
    // Animate in using GSAP (optional)
    gsap.fromTo(part1Ref.current.position, { x: -5 }, { x: part1Pos.x, duration: 1, delay: 0.2 });
    gsap.fromTo(part2Ref.current.position, { y: 5 }, { y: part2Pos.y, duration: 1, delay: 0.4 });
    gsap.fromTo(part3Ref.current.position, { x: 5 }, { x: part3Pos.x, duration: 1, delay: 0.6 });
  }, []);

  // Apply live position updates from Leva
  if (part1Ref.current) part1Ref.current.position.set(part1Pos.x, part1Pos.y, part1Pos.z);
  if (part2Ref.current) part2Ref.current.position.set(part2Pos.x, part2Pos.y, part2Pos.z);
  if (part3Ref.current) part3Ref.current.position.set(part3Pos.x, part3Pos.y, part3Pos.z);

  return (
    <group>
      <OrbitControls/>
      <primitive object={nodes.part1} ref={part1Ref} />
      <primitive object={nodes.part2} ref={part2Ref} />
      <primitive object={nodes.part3} ref={part3Ref} />
    </group>
  );
}

export default Pyramid;
