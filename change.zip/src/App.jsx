import { Canvas } from '@react-three/fiber'
import './App.css'
import Pyramid from './Pyramid.jsx'
import Background from './background.jsx'
import Triangle from './Triangle.jsx'
import CameraTracker from './CameraTracker.jsx'


function App() {

  return (
    <>
    <Canvas camera={{ position: [52.9168,18.7372,64.8875], fov: 45 }}>
      <Triangle/>
    {/* <Pyramid/> */}
    {/* <CameraTracker/> */}
    <Background/>
    </Canvas>
    </>
  )
}

export default App
